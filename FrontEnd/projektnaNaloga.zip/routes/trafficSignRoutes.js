var express = require('express');
var router = express.Router();
var trafficSignController = require('../controllers/trafficSignController.js');

/*
 * GET
 */
router.get('/', trafficSignController.list);

/*
 * GET
 */
router.get('/:id', trafficSignController.show);

/*
 * POST
 */
router.post('/', trafficSignController.create);

/*
 * PUT
 */
router.put('/:id', trafficSignController.update);

/*
 * DELETE
 */
router.delete('/:id', trafficSignController.remove);

module.exports = router;
