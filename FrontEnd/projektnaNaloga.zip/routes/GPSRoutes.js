var express = require('express');
var router = express.Router();
var GPSController = require('../controllers/GPSController.js');

/*
 * GET
 */
router.get('/', GPSController.list);

/*
 * GET
 */
router.get('/:id', GPSController.show);

/*
 * POST
 */
router.post('/', GPSController.create);

/*
 * PUT
 */
router.put('/:id', GPSController.update);

/*
 * DELETE
 */
router.delete('/:id', GPSController.remove);

module.exports = router;
